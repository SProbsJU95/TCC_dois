﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;
using TelasTCC.DB.Endereco;

namespace TelasTCC.DB.Cliente
{
    class ClienteDatabase
    {
        public int Salvar(ClienteDTO dto)
        {
        // testar a possibilidade de erro
            EnderecoDatabase database = new EnderecoDatabase();

            string enderecoCli = database.AtribuirEndereco();
        // testar a possibilidade de erro

            string script = @"insert into cliente (Telefone, Nome, Endereco_idEndereco) values (@Telefone, @Nome,"+ enderecoCli + ")";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Telefone", dto.Telefone));
            parms.Add(new MySqlParameter("Nome", dto.Nome));



            /*parms.Add(new MySqlParameter("tel_cliente_dois", dto.tel_cliente_dois));
            parms.Add(new MySqlParameter("num_residencia_cliente", dto.num_residencia));
            parms.Add(new MySqlParameter("referencia_cliente", dto.referencia));
            parms.Add(new MySqlParameter("complemento_cliente", dto.complemento));*/

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }

        //cad do endereco


        public List<ClienteDTO> Listar()
        {
            string script = "SELECT c.nome, c.Telefone, CONCAT(Rua,' - ', numero,' - ', Bairro) as Enderecos FROM `endereco` INNER JOIN cliente as c where c.Endereco_idEndereco = IdEndereco";

            List<MySqlParameter> parms = new List<MySqlParameter>();

            Database db = new Database();
            MySqlDataReader reader = db.ExecuteSelectScript(script, parms);

            List<ClienteDTO> lista = new List<ClienteDTO>();

            while (reader.Read())
            {
                ClienteDTO dto = new ClienteDTO();
                dto.Nome = reader.GetString("nome");
                dto.Telefone = reader.GetString("Telefone");
                dto.Endereco = reader.GetString("Enderecos");
               
                lista.Add(dto);
            }
            reader.Close();

            return lista;
        }
    }
}
