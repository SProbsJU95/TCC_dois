﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Cliente;
using TelasTCC.DB.Endereco;

namespace TelasTCC
{
    public partial class frmCadCliente : Form
    {
        public frmCadCliente()
        {
            InitializeComponent();
        }

        private void btnCadCliente_Click(object sender, EventArgs e)
        {

        //Cadastro do Endereco do Cliente
            EnderecoDTO dtoE = new EnderecoDTO();
            dtoE.Bairro = txtBairro.Text;
            dtoE.Cep = txtCep.Text;
            dtoE.Complemento = txtComplemento.Text;
            dtoE.Numero = txtNumero.Text;
            dtoE.Rua = txtRua.Text;

            EnderecoBusiness businessE = new EnderecoBusiness();
            businessE.SalvarEndereco(dtoE);

        //Cadastro do Cliente
            ClienteDTO dto = new ClienteDTO();
            dto.Nome = txtNome.Text;
            dto.Telefone = txtTelefone.Text;
            
            ClienteBusiness business = new ClienteBusiness();
            business.Salvar(dto);

            MessageBox.Show("O cliente foi cadastrado com sucesso.");
        }
    }
}
