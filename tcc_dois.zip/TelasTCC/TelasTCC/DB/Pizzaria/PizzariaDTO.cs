﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TelasTCC.DB.Pizzaria
{
    class PizzariaDTO
    {
        public string Produto { get; set; }
        public string IdProduto { get; set; }
        public string QuantidadeProduto { get; set; }


        public string Preco { get; set; }
        public string idPedido { get; set; }
    }
}
