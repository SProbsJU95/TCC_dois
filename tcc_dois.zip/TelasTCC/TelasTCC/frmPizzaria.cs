﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Pizzaria;

namespace TelasTCC
{
    public partial class frmPizzaria : Form
    {
        public frmPizzaria()
        {
            InitializeComponent();
            ListarBebidas();
            ListarSobremesas();
        }

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao) { entregaSalao = entreSalao; }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void gbPizza_Enter(object sender, EventArgs e)
        {

        }

        private void btnEnviarBebidas_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbDose.Text != string.Empty) { dto.Produto = cbDose.Text; }
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            dto.QuantidadeProduto = txtBebidadaQtde.Text;

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");
        }

        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            PizzariaDTO dto = new PizzariaDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }
            dto.QuantidadeProduto = txtSobremesaQtde.Text;

            PizzariaDatabase database = new PizzariaDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            PizzariaBusiness business = new PizzariaBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");
        }

        private void ListarBebidas()
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbDose.DisplayMember = "nome";
            cbSuco.DisplayMember = "nome";
            cbLata.DisplayMember = "nome";

            int i = 0;
            while (i != 3)
            {
                if (i == 0) { DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista; }
                i++;
                if (i == 2) { DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista; }
                i = 3;
            }
        }

        private void ListarSobremesas()
        {
            PizzariaBusiness business = new PizzariaBusiness();

            cbSorvete.DisplayMember = "nome";
            cbDoce.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarPizza_Click(object sender, EventArgs e)
        {
            string script = string.Empty;
            if (checPizza.Checked == true || checEsfirra.Checked == true)
            {
                if (checPizza.Checked == true) { script = "Pizza"; }
                else if (checEsfirra.Checked == true) { script = "Esfirra"; }

                if(checInteira.Checked == true || checMeia.Checked == true || checBroto.Checked == true)
                {
                    if (checInteira.Checked == true) { script += " Inteira"; }
                    else if (checMeia.Checked == true) { script += " Meia"; }
                    else if (checBroto.Checked == true) { script += " Broto"; }
                    MessageBox.Show(script);
                }
                else{MessageBox.Show("Selecione o tamanho!");}
            }
            else{MessageBox.Show("Selecione a caixa 'Pizza' ou 'Esfirra'!");}
        }
    }
}
