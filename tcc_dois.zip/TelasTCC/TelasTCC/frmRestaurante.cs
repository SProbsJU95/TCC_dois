﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;  //apagar
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Restaurante;

namespace TelasTCC
{
    public partial class frmRestaurante : Form
    {
        public frmRestaurante()
        {
            InitializeComponent();
            ListarBebidas();
            ListarSobremesas();
        }

        static int entregaSalao = 0;
        public void setEntregaSalao(int entreSalao){entregaSalao = entreSalao;}


        private void btnEnviar_Click(object sender, EventArgs e)
        {
            txtPeso.Visible = true;
            cbRefeicao.Visible = false;
            txtPeso.Left = 373; 
        }
        
        private void cbPeso_CheckedChanged(object sender, EventArgs e)
        {
            cbFeijoada.Checked = false;
            cbPratoFeito.Checked = false;
        }
        
        private void cbFeijoada_MouseClick(object sender, MouseEventArgs e)
        {
            cbFeijoada.Checked = true;
            cbPratoFeito.Checked = false;
            cbPeso.Checked = false;
        }

        private void cbPratoFeito_MouseClick(object sender, MouseEventArgs e)
        {
            cbPratoFeito.Checked = true;
            cbFeijoada.Checked = false;
            cbPeso.Checked = false;
        }

        private void cbPeso_MouseClick(object sender, MouseEventArgs e)
        {
            cbPeso.Checked = true;
            cbPratoFeito.Checked = false;
            cbFeijoada.Checked = false;
        }

        private void btnEnviarBebida_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbDose.Text != string.Empty){dto.Produto = cbDose.Text;}
            if (cbLata.Text != string.Empty) { dto.Produto = cbLata.Text; }
            if (cbSuco.Text != string.Empty) { dto.Produto = cbSuco.Text; }
            dto.QuantidadeProduto = txtBebidadaQtde.Text;

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();
            
            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Bebida cadastrada.");
        }
        private void ListarBebidas()
        {
            RestauranteBusiness business = new RestauranteBusiness();

            cbDose.DisplayMember = "nome";
            cbSuco.DisplayMember = "nome";
            cbLata.DisplayMember = "nome";
            
            int i = 0;
            while (i != 3)
            {
                if (i == 0) { DataTable lista = business.Listar("Dose"); cbDose.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Suco"); cbSuco.DataSource = lista; }
                i++;
                if (i == 2) { DataTable lista = business.Listar("Lata"); cbLata.DataSource = lista; }
                i = 3;
            }
        }

        private void ListarSobremesas()
        {
            RestauranteBusiness business = new RestauranteBusiness();

            cbSorvete.DisplayMember = "nome";
            cbDoce.DisplayMember = "nome";

            int i = 0;
            while (i != 2)
            {
                if (i == 0) { DataTable lista = business.Listar("Sorvete"); cbSorvete.DataSource = lista; }
                i++;
                if (i == 1) { DataTable lista = business.Listar("Doce"); cbDoce.DataSource = lista; }
                i = 2;
            }
        }

        private void btnEnviarSobremesa_Click(object sender, EventArgs e)
        {
            RestauranteDTO dto = new RestauranteDTO();
            if (cbSorvete.Text != string.Empty) { dto.Produto = cbSorvete.Text; }
            if (cbDoce.Text != string.Empty) { dto.Produto = cbDoce.Text; }
            dto.QuantidadeProduto = txtSobremesaQtde.Text;

            RestauranteDatabase database = new RestauranteDatabase();
            dto.IdProduto = database.ListarProduto(dto.Produto);

            dto.Preco = database.ListarValor(dto.Produto);

            dto.idPedido = database.ListarPedido();

            RestauranteBusiness business = new RestauranteBusiness();
            business.Salvar(dto);
            MessageBox.Show("Sobremesa cadastrada.");
        }
    }
}
