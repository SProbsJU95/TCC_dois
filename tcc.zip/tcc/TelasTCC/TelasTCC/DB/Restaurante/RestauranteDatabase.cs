﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TelasTCC.DB.Base;

namespace TelasTCC.DB.Restaurante
{
    class RestauranteDatabase
    {
        public int Salvar(RestauranteDTO dto)
        {
            string script = @"INSERT SCRIPT";

            List<MySqlParameter> parms = new List<MySqlParameter>();
            parms.Add(new MySqlParameter("Telefone", dto.Bebida));
            parms.Add(new MySqlParameter("Nome", dto.BedidaQuantidade));

            Database db = new Database();
            return db.ExecuteInsetScriptWithPk(script, parms);
        }
        
        public DataTable Listar(string tipo)
        {
            string script = "SELECT `nome` FROM `produto` WHERE `descricao` = '"+tipo+"';";

            Connection conn = new Connection();

            MySqlCommand com = new MySqlCommand();
            com.Connection = conn.Create();
            com.CommandText = script;

            MySqlDataReader reader = com.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            
            return dataTable;
        }
    }
}
