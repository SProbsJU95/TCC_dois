﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TelasTCC.DB.Fornecedores;

namespace TelasTCC
{
    public partial class frmModFornecedores : Form
    {
        public frmModFornecedores()
        {
            InitializeComponent();
            FornecedoresBusiness business = new FornecedoresBusiness();
            List<FornecedoresDTO> lista = business.Listar();

            dgvFornecedores.AutoGenerateColumns = false;
            dgvFornecedores.DataSource = lista;
        }

        frmCadFornecedor forne = new frmCadFornecedor();
        static int i = 0;

        private void btnAdicionar_Click(object sender, EventArgs e)
        {
            forne.SetId(0);
            ChamarCadastro();
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            forne.SetId(1);
            ChamarCadastro();
        }

        public void ChamarCadastro()
        {
            Form cadFornecedores = new frmCadFornecedor();
            if (i == 0)
            {
                cadFornecedores.Show();
                i = 1;
            }
            else if (i == 1)
            {
                cadFornecedores.Hide();
                i = 0;
            }
        }
    }
}
